create proc SP_loaigiay_update(
@MaGiay	char(10),	
@TenGiay	nchar(50),	
@Size	int,
@Soluong	int,
@MauSac	nchar(50),	
@Gia	decimal(8, 0),	
@MaLG	char(10),
@MaNSX	char(10),
@Anh	char(255),
@Mota	text	
)
As
begin
	Update Giay set TenGiay=@TenGiay,Size=@Size,Soluong=@Soluong,MauSac=@MauSac,Gia=@Gia,MaLG=@MaLG,MaNSX=@MaNSX,Anh=@Anh,Mota=@Mota where MaGiay=@MaGiay
end
go

