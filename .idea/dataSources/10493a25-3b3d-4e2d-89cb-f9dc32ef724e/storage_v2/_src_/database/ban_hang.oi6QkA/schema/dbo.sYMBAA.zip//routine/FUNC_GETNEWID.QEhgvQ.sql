CREATE function [dbo].[FUNC_GETNEWID](
	@MaxID char(10),
	@Type char(3)
	)
Returns char(10)
as
Begin
	declare @str char(10)=replace(@MaxID,rtrim(@Type),'0');
	declare @newID char(10) = convert(int,@str)+1
	declare @count int=10-len(rtrim(@Type))-len(@newID)
	set @str=rtrim(@Type)
	while(@count>0)
	begin
		set @str=rtrim(@str)+'0';
		set @count=@count-1;

	end
	set @str=RTRIM(@str)+RTRIM(@newID);
	return @str
end
go

