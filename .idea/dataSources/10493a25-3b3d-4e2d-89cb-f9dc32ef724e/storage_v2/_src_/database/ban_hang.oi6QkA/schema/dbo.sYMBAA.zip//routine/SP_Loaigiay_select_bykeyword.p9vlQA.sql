create proc SP_Loaigiay_select_bykeyword(
	@keyword char(255))
As
begin
	select * from LoaiGiay where MaLG like '%'+@keyword+'%' or TenLG like '%'+@keyword+'%'
end
go

