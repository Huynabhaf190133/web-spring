create proc SP_loaigiay_insert(
	@MaLG	char(10),
	@TenLG	nchar(50)
		)
as
begin
	insert into LoaiGiay values(@MaLG,@TenLG)
end
go

