create proc SP_loaigiay_select_all
as
begin
	select * from LoaiGiay
end
go

